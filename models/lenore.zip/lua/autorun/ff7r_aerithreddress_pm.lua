// Aerith Red Dress - Maygik
player_manager.AddValidModel( "Aerith Red Dress", 	"models/ff7_remake/aerith/aerith_red_dress.mdl" )
player_manager.AddValidHands( "Aerith Red Dress", 	"models/ff7_remake/aerith/aerith_red_dress_arms.mdl", 0, "00000000" )